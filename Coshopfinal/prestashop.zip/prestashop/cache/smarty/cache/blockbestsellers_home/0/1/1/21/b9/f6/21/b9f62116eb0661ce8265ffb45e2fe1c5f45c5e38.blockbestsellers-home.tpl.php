<?php /*%%SmartyHeaderCode:2838256aa3e496de2e2-14835280%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b9f62116eb0661ce8265ffb45e2fe1c5f45c5e38' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\modules\\blockbestsellers\\views\\templates\\hook\\blockbestsellers-home.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
    '98c692f33d0d92cbb7424daf5e6b9528c1026348' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1453696986,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2838256aa3e496de2e2-14835280',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3eac8a3964_21159827',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3eac8a3964_21159827')) {function content_56aa3eac8a3964_21159827($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="blockbestsellers" class="product_list grid row blockbestsellers tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line first-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="Blouse" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/7-home_default/blouse.jpg" alt="Blouse" title="Blouse"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/blouses/2-blouse.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" rel="http://192.168.3.99/prestashop/blouses/2-blouse.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" rel="http://192.168.3.99/prestashop/blouses/2-blouse.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$27.00									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/blouses/2-blouse.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="Blouse" itemprop="url" >
							Blouse
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Short-sleeved blouse with feminine draped sleeve detail.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$27.00							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=2&amp;ipa=7&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="7" data-id-product="2" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="Printed Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/8-home_default/printed-dress.jpg" alt="Printed Dress" title="Printed Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" rel="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" rel="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$26.00									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="Printed Dress" itemprop="url" >
							Printed Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						100% cotton double printed dress. Black and white striped top and orange high waisted skater skirt bottom.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$26.00							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=3&amp;ipa=13&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="13" data-id-product="3" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="Faded Short Sleeves T-shirt" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/1-home_default/faded-short-sleeves-tshirt.jpg" alt="Faded Short Sleeves T-shirt" title="Faded Short Sleeves T-shirt"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" rel="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" rel="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$16.51									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="Faded Short Sleeves T-shirt" itemprop="url" >
							Faded Short Sleeves T-shirt
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Faded short sleeves t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$16.51							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=1&amp;ipa=1&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="1" data-id-product="1" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line first-item-of-tablet-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/20-home_default/printed-chiffon-dress.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$16.40									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$20.50
										</span>
																					<span class="price-percent-reduction">-20%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress" itemprop="url" >
							Printed Chiffon Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Printed chiffon knee length dress with tank straps. Deep v-neckline.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$16.40							</span>
															
								<span class="old-price product-price">
									$20.50
								</span>
								
																	<span class="price-percent-reduction">-20%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=7&amp;ipa=34&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="34" data-id-product="7" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/16-home_default/printed-summer-dress.jpg" alt="Printed Summer Dress" title="Printed Summer Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$30.50									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" >
							Printed Summer Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Sleeveless knee-length chiffon dress. V-neckline with elastic under the bust lining.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$30.50							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=6&amp;ipa=31&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="31" data-id-product="6" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-tablet-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/12-home_default/printed-summer-dress.jpg" alt="Printed Summer Dress" title="Printed Summer Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$28.98									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$30.51
										</span>
																					<span class="price-percent-reduction">-5%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" >
							Printed Summer Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$28.98							</span>
															
								<span class="old-price product-price">
									$30.51
								</span>
								
																	<span class="price-percent-reduction">-5%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=5&amp;ipa=19&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="19" data-id-product="5" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
