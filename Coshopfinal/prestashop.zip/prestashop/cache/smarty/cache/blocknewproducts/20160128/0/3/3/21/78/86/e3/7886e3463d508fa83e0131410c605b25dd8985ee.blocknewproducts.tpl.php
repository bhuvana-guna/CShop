<?php /*%%SmartyHeaderCode:843056aa4182512f02-40125540%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7886e3463d508fa83e0131410c605b25dd8985ee' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blocknewproducts\\blocknewproducts.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '843056aa4182512f02-40125540',
  'variables' => 
  array (
    'link' => 0,
    'new_products' => 0,
    'newproduct' => 0,
    'PS_CATALOG_MODE' => 0,
    'restricted_country_mode' => 0,
    'priceDisplay' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa4182588215_51749834',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa4182588215_51749834')) {function content_56aa4182588215_51749834($_smarty_tpl) {?><!-- MODULE Block new products -->
<div id="new-products_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://192.168.3.99/prestashop/new-products" title="New products">New products</a>
    </h4>
    <div class="block_content products-block">
                    <ul class="products">
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/8-small_default/printed-dress.jpg" alt="Printed Dress" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="Printed Dress">Printed Dress</a>
                            </h5>
                        	<p class="product-description">100% cotton double printed dress. Black and white striped top and orange...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$26.00                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/evening-dresses/4-printed-dress.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/10-small_default/printed-dress.jpg" alt="Printed Dress" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/evening-dresses/4-printed-dress.html" title="Printed Dress">Printed Dress</a>
                            </h5>
                        	<p class="product-description">Printed evening dress with straight sleeves with black thin waist belt...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$50.99                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/12-small_default/printed-summer-dress.jpg" alt="Printed Summer Dress" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress">Printed Summer Dress</a>
                            </h5>
                        	<p class="product-description">Long printed dress with thin adjustable straps. V-neckline and wiring...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$28.98                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/16-small_default/printed-summer-dress.jpg" alt="Printed Summer Dress" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="Printed Summer Dress">Printed Summer Dress</a>
                            </h5>
                        	<p class="product-description">Sleeveless knee-length chiffon dress. V-neckline with elastic under the...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$30.50                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/20-small_default/printed-chiffon-dress.jpg" alt="Printed Chiffon Dress" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress">Printed Chiffon Dress</a>
                            </h5>
                        	<p class="product-description">Printed chiffon knee length dress with tank straps. Deep v-neckline.</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$16.40                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/1-small_default/faded-short-sleeves-tshirt.jpg" alt="Faded Short Sleeves T-shirt" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="Faded Short Sleeves T-shirt">Faded Short Sleeves T-shirt</a>
                            </h5>
                        	<p class="product-description">Faded short sleeves t-shirt with high neckline. Soft and stretchy...</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$16.51                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                                    <li class="clearfix">
                        <a class="products-block-image" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title=""><img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/7-small_default/blouse.jpg" alt="Blouse" /></a>
                        <div class="product-content">
                        	<h5>
                            	<a class="product-name" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="Blouse">Blouse</a>
                            </h5>
                        	<p class="product-description">Short-sleeved blouse with feminine draped sleeve detail.</p>
                                                        	                                    <div class="price-box">
                                        <span class="price">
                                        	$27.00                                        </span>
                                        
                                    </div>
                                                                                    </div>
                    </li>
                            </ul>
            <div>
                <a href="http://192.168.3.99/prestashop/new-products" title="All new products" class="btn btn-default button button-small"><span>All new products<i class="icon-chevron-right right"></i></span></a>
            </div>
            </div>
</div>
<!-- /MODULE Block new products --><?php }} ?>
