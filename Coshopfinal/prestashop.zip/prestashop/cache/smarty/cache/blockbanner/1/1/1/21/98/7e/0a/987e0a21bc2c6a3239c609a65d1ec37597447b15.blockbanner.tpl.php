<?php /*%%SmartyHeaderCode:1831756aa3e4a000a41-69000518%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '987e0a21bc2c6a3239c609a65d1ec37597447b15' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\modules\\blockbanner\\blockbanner.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1831756aa3e4a000a41-69000518',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3e5bb79d99_91771186',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3e5bb79d99_91771186')) {function content_56aa3e5bb79d99_91771186($_smarty_tpl) {?><a href="http://192.168.3.99/prestashop/" title="">
	<img class="img-responsive" src="https://192.168.3.99/prestashop/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" />
</a>
<?php }} ?>
