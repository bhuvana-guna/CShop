<?php /*%%SmartyHeaderCode:705256aa3e497c4ad8-78467405%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '12cdb8512b95e00264fe9ebd0a521116bfdd53a4' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '705256aa3e497c4ad8-78467405',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3e656ec770_74881981',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3e656ec770_74881981')) {function content_56aa3e656ec770_74881981($_smarty_tpl) {?><section id="social_block" class="pull-right">
	<ul>
					<li class="facebook">
				<a class="_blank" href="http://www.facebook.com/prestashop">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a class="_blank" href="http://www.twitter.com/prestashop">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a class="_blank" href="http://www.prestashop.com/blog/en/">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a class="_blank" href="https://www.google.com/+prestashop" rel="publisher">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
    <h4>Follow us</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
