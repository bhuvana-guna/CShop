<?php /*%%SmartyHeaderCode:187356aa3e49d58984-75335446%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '967a99ddbd6e207b429768f96a0daf01d459a26d' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '187356aa3e49d58984-75335446',
  'variables' => 
  array (
    'blockcontactinfos_company' => 0,
    'blockcontactinfos_address' => 0,
    'blockcontactinfos_phone' => 0,
    'blockcontactinfos_email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3e49d87799_62304341',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3e49d87799_62304341')) {function content_56aa3e49d87799_62304341($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <h4>Store Information</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>My Company, 42 Puffin street
12345 Puffinville
France            	</li>
                                    	<li>
            		<i class="icon-phone"></i>Call us now: 
            		<span>0123-456-789</span>
            	</li>
                                    	<li>
            		<i class="icon-envelope-alt"></i>Email: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%61%6c%65%73@%79%6f%75%72%63%6f%6d%70%61%6e%79.%63%6f%6d" >&#x73;&#x61;&#x6c;&#x65;&#x73;&#x40;&#x79;&#x6f;&#x75;&#x72;&#x63;&#x6f;&#x6d;&#x70;&#x61;&#x6e;&#x79;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
