<?php /*%%SmartyHeaderCode:2556956aa3e48487f30-47895539%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0bb6341d96e1bd69fb3ce527584d53a9b3d64865' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\modules\\blockfacebook\\blockfacebook.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2556956aa3e48487f30-47895539',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3eabbc2041_73313992',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3eabbc2041_73313992')) {function content_56aa3eabbc2041_73313992($_smarty_tpl) {?><div id="fb-root"></div>
<div id="facebook_block" class="col-xs-4">
	<h4 >Follow us on Facebook</h4>
	<div class="facebook-fanbox">
		<div class="fb-like-box" data-href="https://www.facebook.com/prestashop" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false">
		</div>
	</div>
</div>
<?php }} ?>
