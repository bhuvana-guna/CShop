<?php /*%%SmartyHeaderCode:228856aa4181415046-29135704%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1189c73ed7f947cb35da84c4735af8193b2b1c57' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
    'a5fb919cc02c96f2e2337341c4fa47027ced9ca0' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '228856aa4181415046-29135704',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa43a21460f9_15271846',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa43a21460f9_15271846')) {function content_56aa43a21460f9_15271846($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					Tops
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://192.168.3.99/prestashop/5-tshirts" title="The must have of your wardrobe, take a look at our different colors, 
 shapes and style of our collection!">
		T-shirts
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://192.168.3.99/prestashop/7-blouses" title="Match your favorites blouses with the right accessories for the perfect look.">
		Blouses
	</a>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
