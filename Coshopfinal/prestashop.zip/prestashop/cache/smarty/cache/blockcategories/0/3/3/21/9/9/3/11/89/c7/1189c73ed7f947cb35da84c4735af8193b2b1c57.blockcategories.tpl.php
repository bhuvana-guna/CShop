<?php /*%%SmartyHeaderCode:228856aa4181415046-29135704%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1189c73ed7f947cb35da84c4735af8193b2b1c57' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '228856aa4181415046-29135704',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa435edd7721_29414707',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa435edd7721_29414707')) {function content_56aa435edd7721_29414707($_smarty_tpl) {?><?php }} ?>
