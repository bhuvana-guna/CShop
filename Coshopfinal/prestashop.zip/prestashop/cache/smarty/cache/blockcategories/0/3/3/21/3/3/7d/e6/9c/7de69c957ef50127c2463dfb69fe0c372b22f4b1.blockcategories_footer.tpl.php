<?php /*%%SmartyHeaderCode:482156aa3e4998dc43-87697802%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7de69c957ef50127c2463dfb69fe0c372b22f4b1' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
    'a5fb919cc02c96f2e2337341c4fa47027ced9ca0' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '482156aa3e4998dc43-87697802',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa4183caa556_71186631',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa4183caa556_71186631')) {function content_56aa4183caa556_71186631($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Categories</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li class="last">
	<a 
	href="http://192.168.3.99/prestashop/3-women" class="selected" title="You will find here all woman fashion collections.  
 This category includes all the basics of your wardrobe and much more: 
 shoes, accessories, printed t-shirts, feminine dresses, women&#039;s jeans!">
		Women
	</a>
			<ul>
												
<li >
	<a 
	href="http://192.168.3.99/prestashop/4-tops" title="Choose from t-shirts, tops, blouses, short sleeves, long sleeves, tank tops, 3/4 sleeves and more. 
 Find the cut that suits you the best!">
		Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://192.168.3.99/prestashop/5-tshirts" title="The must have of your wardrobe, take a look at our different colors, 
 shapes and style of our collection!">
		T-shirts
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://192.168.3.99/prestashop/7-blouses" title="Match your favorites blouses with the right accessories for the perfect look.">
		Blouses
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://192.168.3.99/prestashop/8-dresses" title="Find your favorites dresses from our wide choice of evening, casual or summer dresses! 
 We offer dresses for every day, every style and every occasion.">
		Dresses
	</a>
			<ul>
												
<li >
	<a 
	href="http://192.168.3.99/prestashop/9-casual-dresses" title="You are looking for a dress for every day? Take a look at 
 our selection of dresses to find one that suits you.">
		Casual Dresses
	</a>
	</li>

																
<li >
	<a 
	href="http://192.168.3.99/prestashop/10-evening-dresses" title="Browse our different dresses to choose the perfect dress for an unforgettable evening!">
		Evening Dresses
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://192.168.3.99/prestashop/11-summer-dresses" title="Short dress, long dress, silk dress, printed dress, you will find the perfect dress for summer.">
		Summer Dresses
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
