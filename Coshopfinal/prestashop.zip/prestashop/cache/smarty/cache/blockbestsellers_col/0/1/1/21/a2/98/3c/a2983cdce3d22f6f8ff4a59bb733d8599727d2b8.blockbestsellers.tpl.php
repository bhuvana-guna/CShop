<?php /*%%SmartyHeaderCode:3236156aa41cece1576-26525250%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a2983cdce3d22f6f8ff4a59bb733d8599727d2b8' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockbestsellers\\blockbestsellers.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3236156aa41cece1576-26525250',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa423d0c1a04_61524552',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa423d0c1a04_61524552')) {function content_56aa423d0c1a04_61524552($_smarty_tpl) {?>
<!-- MODULE Block best sellers -->
<div id="best-sellers_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://192.168.3.99/prestashop/best-sales" title="View a top sellers products">Top sellers</a>
    </h4>
	<div class="block_content">
			<ul class="block_content products-block">
						<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/7-small_default/blouse.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/blouses/2-blouse.html" title="">
                            Blouse
                        </a>
                    </h5>
                    <p class="product-description">Short-sleeved blouse with feminine draped sleeve detail.</p>
                                            <div class="price-box">
                            <span class="price">$27.00</span>
                            
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/8-small_default/printed-dress.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/casual-dresses/3-printed-dress.html" title="">
                            Printed Dress
                        </a>
                    </h5>
                    <p class="product-description">100% cotton double printed dress. Black and white striped top and orange...</p>
                                            <div class="price-box">
                            <span class="price">$26.00</span>
                            
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/1-small_default/faded-short-sleeves-tshirt.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/tshirts/1-faded-short-sleeves-tshirt.html" title="">
                            Faded Short Sleeves T-shirt
                        </a>
                    </h5>
                    <p class="product-description">Faded short sleeves t-shirt with high neckline. Soft and stretchy...</p>
                                            <div class="price-box">
                            <span class="price">$16.51</span>
                            
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/20-small_default/printed-chiffon-dress.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="">
                            Printed Chiffon Dress
                        </a>
                    </h5>
                    <p class="product-description">Printed chiffon knee length dress with tank straps. Deep v-neckline.</p>
                                            <div class="price-box">
                            <span class="price">$16.40</span>
                            
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/16-small_default/printed-summer-dress.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/6-printed-summer-dress.html" title="">
                            Printed Summer Dress
                        </a>
                    </h5>
                    <p class="product-description">Sleeveless knee-length chiffon dress. V-neckline with elastic under the...</p>
                                            <div class="price-box">
                            <span class="price">$30.50</span>
                            
                        </div>
                                    </div>
			</li>
					<li class="clearfix">
				<a href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="" class="products-block-image content_img clearfix">
					<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/12-small_default/printed-summer-dress.jpg" alt="" />
				</a>
				<div class="product-content">
                	<h5>
                    	<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="">
                            Printed Summer Dress
                        </a>
                    </h5>
                    <p class="product-description">Long printed dress with thin adjustable straps. V-neckline and wiring...</p>
                                            <div class="price-box">
                            <span class="price">$28.98</span>
                            
                        </div>
                                    </div>
			</li>
				</ul>
		<div class="lnk">
        	<a href="http://192.168.3.99/prestashop/best-sales" title="All best sellers"  class="btn btn-default button button-small"><span>All best sellers<i class="icon-chevron-right right"></i></span></a>
        </div>
		</div>
</div>
<!-- /MODULE Block best sellers --><?php }} ?>
