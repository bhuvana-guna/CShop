<?php /*%%SmartyHeaderCode:1767056aa3e489a2c23-06548233%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cec639a70dbc5ad01fb6b950a1c3ada0f9ed5932' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1767056aa3e489a2c23-06548233',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3eac236450_23731803',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3eac236450_23731803')) {function content_56aa3eac236450_23731803($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">New arrivals</a></li>
<?php }} ?>
