<?php /*%%SmartyHeaderCode:1908856aa3e4a16bf79-79811901%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3923e04e6a510d4fed34774f7c58ed1546dfe902' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcontact\\nav.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1908856aa3e4a16bf79-79811901',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3e5bcaa899_98869439',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3e5bcaa899_98869439')) {function content_56aa3e5bcaa899_98869439($_smarty_tpl) {?><div id="contact-link" >
	<a href="https://192.168.3.99/prestashop/contact-us" title="Contact us">Contact us</a>
</div>
	<span class="shop-phone">
		<i class="icon-phone"></i>Call us now: <strong>0123-456-789</strong>
	</span>
<?php }} ?>
