<?php /*%%SmartyHeaderCode:1743656aa4182718861-22775660%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6b4cf96383f51a02ff5397c2d34ac56408e78c7c' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockspecials\\blockspecials.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1743656aa4182718861-22775660',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa41cf53d189_31753377',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa41cf53d189_31753377')) {function content_56aa41cf53d189_31753377($_smarty_tpl) {?>
<!-- MODULE Block specials -->
<div id="special_block_right" class="block">
	<p class="title_block">
        <a href="http://192.168.3.99/prestashop/prices-drop" title="Specials">
            Specials
        </a>
    </p>
	<div class="block_content products-block">
    		<ul>
        	<li class="clearfix">
            	<a class="products-block-image" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
                    <img 
                    class="replace-2x img-responsive" 
                    src="http://192.168.3.99/prestashop/20-small_default/printed-chiffon-dress.jpg" 
                    alt="" 
                    title="Printed Chiffon Dress" />
                </a>
                <div class="product-content">
                	<h5>
                        <a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress">
                            Printed Chiffon Dress
                        </a>
                    </h5>
                                        	<p class="product-description">
                            Printed chiffon knee length dress...
                        </p>
                                        <div class="price-box">
                    	                        	<span class="price special-price">
                                $16.40
                                                            </span>
                                                                                                                                 <span class="price-percent-reduction">-20%</span>
                                                                                         <span class="old-price">
                                $20.50
                                                            </span>
                            
                                            </div>
                </div>
            </li>
		</ul>
		<div>
			<a 
            class="btn btn-default button button-small" 
            href="http://192.168.3.99/prestashop/prices-drop" 
            title="All specials">
                <span>All specials<i class="icon-chevron-right right"></i></span>
            </a>
		</div>
    	</div>
</div>
<!-- /MODULE Block specials -->
<?php }} ?>
