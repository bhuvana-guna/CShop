<?php /*%%SmartyHeaderCode:2572056aa3e49c56bf2-46675223%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b9620b5ea973c4f62b8092850ed58cd48e571d8' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockmyaccountfooter\\blockmyaccountfooter.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2572056aa3e49c56bf2-46675223',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3e65875182_31860153',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3e65875182_31860153')) {function content_56aa3e65875182_31860153($_smarty_tpl) {?>
<!-- Block myaccount module -->
<section class="footer-block col-xs-12 col-sm-4">
	<h4><a href="https://192.168.3.99/prestashop/my-account" title="Manage my customer account" rel="nofollow">My account</a></h4>
	<div class="block_content toggle-footer">
		<ul class="bullet">
			<li><a href="https://192.168.3.99/prestashop/order-history" title="My orders" rel="nofollow">My orders</a></li>
						<li><a href="https://192.168.3.99/prestashop/credit-slip" title="My credit slips" rel="nofollow">My credit slips</a></li>
			<li><a href="https://192.168.3.99/prestashop/addresses" title="My addresses" rel="nofollow">My addresses</a></li>
			<li><a href="https://192.168.3.99/prestashop/identity" title="Manage my personal information" rel="nofollow">My personal info</a></li>
						
            <li><a href="http://192.168.3.99/prestashop/?mylogout" title="Sign out" rel="nofollow">Sign out</a></li>		</ul>
	</div>
</section>
<!-- /Block myaccount module -->
<?php }} ?>
