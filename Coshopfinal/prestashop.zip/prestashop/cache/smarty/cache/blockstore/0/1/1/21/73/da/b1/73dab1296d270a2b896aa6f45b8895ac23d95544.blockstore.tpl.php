<?php /*%%SmartyHeaderCode:1437356aa4182864902-80863541%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '73dab1296d270a2b896aa6f45b8895ac23d95544' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockstore\\blockstore.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1437356aa4182864902-80863541',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa422fb72dc0_35396797',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa422fb72dc0_35396797')) {function content_56aa422fb72dc0_35396797($_smarty_tpl) {?>
<!-- Block stores module -->
<div id="stores_block_left" class="block">
	<p class="title_block">
		<a href="http://192.168.3.99/prestashop/stores" title="Our stores">
			Our stores
		</a>
	</p>
	<div class="block_content blockstore">
		<p class="store_image">
			<a href="http://192.168.3.99/prestashop/stores" title="Our stores">
				<img class="img-responsive" src="http://192.168.3.99/prestashop/modules/blockstore/store.jpg" alt="Our stores" />
			</a>
		</p>
				<div>
			<a 
			class="btn btn-default button button-small" 
			href="http://192.168.3.99/prestashop/stores" 
			title="Our stores">
				<span>Discover our stores<i class="icon-chevron-right right"></i></span>
			</a>
		</div>
	</div>
</div>
<!-- /Block stores module -->
<?php }} ?>
