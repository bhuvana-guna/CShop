<?php /*%%SmartyHeaderCode:2914756aa3e49b02dc1-39472161%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c67f9ac215d64cd8b9f83ef4a6eed073f93ef44b' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\modules\\blockcms\\blockcms.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2914756aa3e49b02dc1-39472161',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa4181945250_97258178',
  'has_nocache_code' => true,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa4181945250_97258178')) {function content_56aa4181945250_97258178($_smarty_tpl) {?>
	<!-- Block CMS module -->
			<section id="informations_block_left_1" class="block informations_block_left">
			<p class="title_block">
				<a href="http://192.168.3.99/prestashop/content/category/1-home">
					Information				</a>
			</p>
			<div class="block_content list-block">
				<ul>
																							<li>
								<a href="http://192.168.3.99/prestashop/content/1-delivery" title="Delivery">
									Delivery
								</a>
							</li>
																								<li>
								<a href="http://192.168.3.99/prestashop/content/2-legal-notice" title="Legal Notice">
									Legal Notice
								</a>
							</li>
																								<li>
								<a href="http://192.168.3.99/prestashop/content/3-terms-and-conditions-of-use" title="Terms and conditions of use">
									Terms and conditions of use
								</a>
							</li>
																								<li>
								<a href="http://192.168.3.99/prestashop/content/4-about-us" title="About us">
									About us
								</a>
							</li>
																								<li>
								<a href="http://192.168.3.99/prestashop/content/5-secure-payment" title="Secure payment">
									Secure payment
								</a>
							</li>
																						<li>
							<a href="http://192.168.3.99/prestashop/stores" title="Our stores">
								Our stores
							</a>
						</li>
									</ul>
			</div>
		</section>
		<!-- /Block CMS module -->
<?php }} ?>
