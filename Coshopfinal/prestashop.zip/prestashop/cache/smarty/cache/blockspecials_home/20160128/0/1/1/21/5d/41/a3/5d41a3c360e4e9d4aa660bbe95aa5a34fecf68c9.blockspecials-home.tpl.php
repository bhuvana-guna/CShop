<?php /*%%SmartyHeaderCode:1180156aa3e495ff7e0-32483035%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d41a3c360e4e9d4aa660bbe95aa5a34fecf68c9' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\modules\\blockspecials\\views\\templates\\hook\\blockspecials-home.tpl',
      1 => 1452079228,
      2 => 'file',
    ),
    '98c692f33d0d92cbb7424daf5e6b9528c1026348' => 
    array (
      0 => 'C:\\xamppnew\\htdocs\\prestashop\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1453696986,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1180156aa3e495ff7e0-32483035',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56aa3eac735f52_78923416',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56aa3eac735f52_78923416')) {function content_56aa3eac735f52_78923416($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="blockspecials" class="product_list grid row blockspecials tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/12-home_default/printed-summer-dress.jpg" alt="Printed Summer Dress" title="Printed Summer Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$28.98									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$30.51
										</span>
																					<span class="price-percent-reduction">-5%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url" >
							Printed Summer Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$28.98							</span>
															
								<span class="old-price product-price">
									$30.51
								</span>
								
																	<span class="price-percent-reduction">-5%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=5&amp;ipa=19&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="19" data-id-product="5" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/summer-dresses/5-printed-summer-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress" itemprop="url" draggable="true" ondragstart="return ChatShareJS.drag(event)" >
							<img class="replace-2x img-responsive" src="http://192.168.3.99/prestashop/20-home_default/printed-chiffon-dress.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress"  width="250" height="250" itemprop="image" data_link="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html"/>
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" rel="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$16.40									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$20.50
										</span>
																					<span class="price-percent-reduction">-20%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="Printed Chiffon Dress" itemprop="url" >
							Printed Chiffon Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Printed chiffon knee length dress with tank straps. Deep v-neckline.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$16.40							</span>
															
								<span class="old-price product-price">
									$20.50
								</span>
								
																	<span class="price-percent-reduction">-20%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="https://192.168.3.99/prestashop/cart?add=1&amp;id_product=7&amp;ipa=34&amp;token=78033987b801ee7f8dde78c263fc9f2b" rel="nofollow" title="Add to cart" data-id-product-attribute="34" data-id-product="7" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://192.168.3.99/prestashop/summer-dresses/7-printed-chiffon-dress.html" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
